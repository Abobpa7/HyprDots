
require("nvim-tree").setup()
