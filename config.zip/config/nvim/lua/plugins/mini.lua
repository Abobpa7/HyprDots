
require('mini.move').setup()
require('mini.pairs').setup()
