
require'colorizer'.setup()
