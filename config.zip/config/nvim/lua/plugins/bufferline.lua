
vim.opt.termguicolors = true
require("bufferline").setup{}
